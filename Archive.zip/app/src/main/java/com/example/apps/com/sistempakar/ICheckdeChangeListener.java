package com.example.apps.com.sistempakar;

/**
 * Created by RONIJR on 8/2/18.
 */

public interface ICheckdeChangeListener {
    void onItemChecked(int position, boolean value);
}
